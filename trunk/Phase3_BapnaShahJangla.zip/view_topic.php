<?php
require_once('lib.php');

if($_GET['id']!=''){
$topic_id=$_GET['id'];
} else {
	$topic_id=$_POST['topic_id_var'];
}

$topic_name=mysql_result(mysql_query("SELECT topic.NAME FROM topic WHERE topic.TOPIC_ID='$topic_id'"),0,"NAME");


$qdelid=$_GET['qdelid'];
if($qdelid!=''){
	$query = "  DELETE FROM question  WHERE question.QUESTION_ID='$qdelid'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record deleted";
	}

}


if($_POST['qtype']=='TF'){
$query = " INSERT INTO question VALUES ('','$_POST[TF_question]','$_POST[TF_points]', 'TF', '$curr_user_id', '$topic_id', '$_POST[TF_answer]')";
	if(!mysql_query($query)) {
		echo "failed1";
	} else {
		echo "1 record added";
	}
	
}

if($_POST['qtype']=='MCQ'){
$query = " INSERT INTO question VALUES ('','$_POST[MCQ_question]','$_POST[MCQ_points]', 'MCQ', '$curr_user_id', '$topic_id', '$_POST[MCQ_answer]')";
	if(!mysql_query($query)) {
		echo "failed2";
	} else {
		echo "1 record added";
	}



$q = "select MAX(QUESTION_ID) from question";
$resultq = mysql_query($q);
$data = mysql_fetch_array($resultq);
$MCQ_question_id=$data[0];



mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_1]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_2]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_3]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_4]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_5]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_6]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_7]')    ") ;
mysql_query("    INSERT INTO mc_ans_wrong VALUES ('$MCQ_question_id', '', '$_POST[MCQ_wrong_8]')    ") ;

	
}


if($_POST['edit_tf']){
	
	$query = "   UPDATE	question SET question.QUESTION_TEXT='$_POST[TF_question]', question.QUESTION_POINTS='$_POST[TF_points]', question.QUESTION_ANS='$_POST[TF_answer]' WHERE	question.QUESTION_ID='$_POST[question_id]'  ";
	
	
	if(!mysql_query($query)) {
		echo "failed3";
	} else {
		echo "1 record updated";
	}
	
}

if($_POST['edit_mcq']){
	
	$query = "   UPDATE	question SET question.QUESTION_TEXT='$_POST[MCQ_question]', question.QUESTION_POINTS='$_POST[MCQ_points]', question.QUESTION_ANS='$_POST[MCQ_answer]' WHERE	question.QUESTION_ID='$_POST[question_id]'  ";
	
	
	if(!mysql_query($query)) {
		echo "failed4";
	} else {
		echo "1 record updated";
	}

mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_1_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_1_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_2_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_2_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_3_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_3_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_4_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_4_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_5_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_5_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_6_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_6_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_7_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_7_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_8_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_8_id]'    ") ;	
	
}

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
    <script type="text/javascript">
function hideAll() {
  document.getElementById("TF").style.display = "none";
  document.getElementById("MCQ").style.display = "none";
}

function showDiv(sel) {
  hideAll();
  if (sel.selectedIndex != -1)
    {document.getElementById(sel.options[sel.selectedIndex].value).style.display = "block";	}
	}


</script>

  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="topic_mgmt.php" style="color:#FFF"> Question Library Management </a> ---> View Questions in Topic
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM topic NATURAL JOIN question NATURAL JOIN instr_user WHERE TOPIC_ID=$topic_id ");

echo "
    <h1>
      Questions in topic \"$topic_name\"
    </h1>
	<br>
	<input type=\"button\" onClick=\"window.location.href='search_topic_question.php?tid=$topic_id'\" value=\"Search for a question\"/>

<table class='box'>
<tr>
<th  NOWRAP>Question ID</th>
<th>Question</th>
<th>Instructor</th>
<th  NOWRAP colspan=\"3\"><a href=\"view_topic_print.php?tid=" . $topic_id . "\">view printable version of this</a></th>

</tr>";



while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['QUESTION_ID'] . "</td>";
  echo "<td>" . $row['QUESTION_TEXT'] . "</td>";
  echo "<td NOWRAP>" . $row['FIRST_NAME'] . " " . $row['LAST_NAME'] . "</td>";
  echo "<td><a href=\"edit_question.php?qid=" . $row['QUESTION_ID'] . "&tid=" . $topic_id . "\">Edit question</a></td>";
  echo "<td><a href=\"view_topic.php?id=" . $topic_id . "&qdelid=" . $row['QUESTION_ID'] . "\">Delete question</a></td>";
  echo "</tr>";
  }
echo "</table>";

?>
  
  

    <h1>
      Create a new question in this topic
    </h1>
    <? include('error.php'); ?>

   <table class="box">      
<tr>
        <td>* Question Type</td>
        <td>
        <select onChange="showDiv(this)">
        <option value="TF">TF</option>
        <option value="MCQ">MCQ</option>
        </select>
        </td>
      </tr>
</table>

  <div id="TF" style="display:block">
  <form action="view_topic.php" method="POST" name="tf_form">
    <table class="box">
      <tr>
        <td>* Question</td>
        <td><input type="text" name="TF_question" /></td>
      </tr>
      <tr>
        <td>* # Points</td>
        <td><input type="text" name="TF_points" /></td>
      </tr>
      <tr>
        <td>* Answer</td>
        <td><select name="TF_answer"><option value="true">True</option><option value="false">False</option></select></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="qtype" value="TF">        
          <input type="hidden" name="question_type_tf" id="1">
          <input type="hidden" name="topic_id_var" value=<? echo $topic_id ?>>
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
    </form>
    </div>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("tf_form");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("TF_question","req","Please enter a question");
 
 frmvalidator.addValidation("TF_points","req","Please enter number of points for this question");
 frmvalidator.addValidation("TF_points","numeric","numeric values only");
 frmvalidator.addValidation("TF_points","maxlength=2","Exceeded max number of points per question");


 
</script>      
    
<div id="MCQ" style="display:none">
  <form action="view_topic.php" method="POST" name="mcq_form">
    <table class="box">
      <tr>
        <td>* Question</td>
        <td><input type="text" name="MCQ_question" /></td>
      </tr>
      <tr>
        <td>* # Points</td>
        <td><input type="text" name="MCQ_points" /></td>
      </tr>
      <tr>
        <td>* Answer</td>
        <td><textarea name="MCQ_answer" rows="2" cols="20"></textarea></td>
      </tr>
      
      <tr>
        <td>* Wrong Ans 1</td>
        <td><textarea name="MCQ_wrong_1" rows="2" cols="20"></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 2</td>
        <td><textarea name="MCQ_wrong_2" rows="2" cols="20"></textarea></td>
      </tr>      
      <tr>
        <td>* Wrong Ans 3</td>
        <td><textarea name="MCQ_wrong_3" rows="2" cols="20"></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 4</td>
        <td><textarea name="MCQ_wrong_4" rows="2" cols="20"></textarea></td>
      </tr>          
      <tr>
        <td>* Wrong Ans 5</td>
        <td><textarea name="MCQ_wrong_5" rows="2" cols="20"></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 6</td>
        <td><textarea name="MCQ_wrong_6" rows="2" cols="20"></textarea></td>
      </tr>      
      <tr>
        <td>* Wrong Ans 7</td>
        <td><textarea name="MCQ_wrong_7" rows="2" cols="20"></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 8</td>
        <td><textarea name="MCQ_wrong_8" rows="2" cols="20"></textarea></td>
      </tr>  

      
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="qtype" value="MCQ">        
          <input type="hidden" name="question_type_mcq" id="2">
          <input type="hidden" name="topic_id_var" value=<? echo $topic_id ?>>
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>

</form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("mcq_form");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("MCQ_question","req","Please enter a question");
 
 frmvalidator.addValidation("MCQ_points","req","Please enter number of points for this question");
 frmvalidator.addValidation("MCQ_points","numeric","numeric values only");
 frmvalidator.addValidation("MCQ_points","maxlength=2","Exceeded max number of points per question");

 frmvalidator.addValidation("MCQ_answer","req","Please enter an answer");

 
</script>  
</div>
  
  
  </body>
</html>

<? mysql_close($conn); ?>