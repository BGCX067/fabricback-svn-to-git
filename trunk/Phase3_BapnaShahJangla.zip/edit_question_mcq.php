<?php

$topic_id=$_GET['tid'];
$q_id=$_GET['qid'];

$query="SELECT * FROM question NATURAL JOIN mc_ans_wrong WHERE question.QUESTION_ID='$q_id' ORDER BY mc_ans_wrong.WRONG_ANS_ID";
$result=mysql_query($query);

$MCQ_question=mysql_result($result,0,"QUESTION_TEXT");
$MCQ_points=mysql_result($result,0,"QUESTION_POINTS");
$MCQ_answer=mysql_result($result,0,"QUESTION_ANS");

$MCQ_wrong_ans_1_text=mysql_result($result,0,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_1_id=mysql_result($result,0,"WRONG_ANS_ID");

$MCQ_wrong_ans_2_text=mysql_result($result,1,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_2_id=mysql_result($result,1,"WRONG_ANS_ID");

$MCQ_wrong_ans_3_text=mysql_result($result,2,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_3_id=mysql_result($result,2,"WRONG_ANS_ID");

$MCQ_wrong_ans_4_text=mysql_result($result,3,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_4_id=mysql_result($result,3,"WRONG_ANS_ID");

$MCQ_wrong_ans_5_text=mysql_result($result,4,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_5_id=mysql_result($result,4,"WRONG_ANS_ID");

$MCQ_wrong_ans_6_text=mysql_result($result,5,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_6_id=mysql_result($result,5,"WRONG_ANS_ID");

$MCQ_wrong_ans_7_text=mysql_result($result,6,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_8_text=mysql_result($result,7,"WRONG_ANS_TEXT");
$MCQ_wrong_ans_8_id=mysql_result($result,7,"WRONG_ANS_ID");
$MCQ_wrong_ans_7_id=mysql_result($result,6,"WRONG_ANS_ID");


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="topic_mgmt.php" style="color:#FFF"> Question Library Management </a> ---> <a href="view_topic.php?id=<? echo $topic_id ?> "style="color:#FFF"> View Questions in Topic </a> ---> Edit Question  </div>
  <!-- /BreadCrumbs -->

  
  
  
  <form action="view_topic.php?id=<? echo $topic_id ?>" method="POST" name="mcq_form">
    <? include('error.php'); ?>
    <h1>
      Edit selected MCQ question
    </h1>
    <table class="box">
      <tr>
        <td>* Question</td>
        <td><input type="text" name="MCQ_question" value="<? echo $MCQ_question ?>" /></td>
      </tr>
      <tr>
        <td>* # Points</td>
        <td><input type="text" name="MCQ_points" value="<? echo $MCQ_points ?>" /></td>
      </tr>
      <tr>
        <td>* Answer</td>
        <td><textarea name="MCQ_answer" rows="2" cols="20"><? echo $MCQ_answer ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 1</td>
        <td><textarea name="MCQ_wrong_ans_1_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_1_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 2</td>
        <td><textarea name="MCQ_wrong_ans_2_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_2_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 3</td>
        <td><textarea name="MCQ_wrong_ans_3_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_3_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 4</td>
        <td><textarea name="MCQ_wrong_ans_4_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_4_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 5</td>
        <td><textarea name="MCQ_wrong_ans_5_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_5_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 6</td>
        <td><textarea name="MCQ_wrong_ans_6_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_6_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 7</td>
        <td><textarea name="MCQ_wrong_ans_7_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_7_text ?></textarea></td>
      </tr>
      <tr>
        <td>* Wrong Ans 8</td>
        <td><textarea name="MCQ_wrong_ans_8_text" rows="2" cols="20"><? echo $MCQ_wrong_ans_8_text ?></textarea></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="MCQ_wrong_ans_1_id" value="<? echo $MCQ_wrong_ans_1_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_2_id" value="<? echo $MCQ_wrong_ans_2_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_3_id" value="<? echo $MCQ_wrong_ans_3_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_4_id" value="<? echo $MCQ_wrong_ans_4_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_5_id" value="<? echo $MCQ_wrong_ans_5_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_6_id" value="<? echo $MCQ_wrong_ans_6_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_7_id" value="<? echo $MCQ_wrong_ans_7_id ?>" />
          <input type="hidden" name="MCQ_wrong_ans_8_id" value="<? echo $MCQ_wrong_ans_8_id ?>" />
          <input type="hidden" name="topic_id" value="<? echo $topic_id ?>" />
          <input type="hidden" name="question_id" value="<? echo $q_id ?>" />
          <input type="hidden" name="edit_mcq" value="true" />          
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("mcq_form");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("MCQ_question","req","Please enter a question");
 
 frmvalidator.addValidation("MCQ_points","req","Please enter number of points for this question");
 frmvalidator.addValidation("MCQ_points","numeric","numeric values only");
 frmvalidator.addValidation("MCQ_points","maxlength=2","Exceeded max number of points per question");

 frmvalidator.addValidation("MCQ_answer","req","Please enter an answer");

 
</script> 
  
  </body>
</html>

