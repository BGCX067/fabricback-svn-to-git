<?
require_once('lib.php');

$q_id = $_GET['qid'];


if (  mysql_result(mysql_query("SELECT question.QUESTION_TYPE FROM question WHERE question.QUESTION_ID='$q_id'"),0,"QUESTION_TYPE") =='TF' ){
include 'edit_question_tf.php';
}

if (  mysql_result(mysql_query("SELECT question.QUESTION_TYPE FROM question WHERE question.QUESTION_ID='$q_id'"),0,"QUESTION_TYPE") =='MCQ' ){
include 'edit_question_mcq.php';
}

mysql_close($conn);

?>