<?php
require_once('lib.php');

$topic_id=$_GET['tid'];
$topic_name=mysql_result(mysql_query("SELECT topic.NAME FROM topic WHERE topic.TOPIC_ID='$topic_id'"),0,"NAME");

?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="topic_mgmt.php" style="color:#FFF"> Question Library Management </a> ---> <a href="view_topic.php?id=<? echo $topic_id ?> "style="color:#FFF"> View Questions in Topic </a> ---> Printable version  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM topic NATURAL JOIN question NATURAL JOIN instr_user WHERE TOPIC_ID=$topic_id ");

echo "
    <h1>
      Questions in topic \"$topic_name\" (printable version)
    </h1>
	<br>
<input type=\"button\" onClick=\"window.print()\" value=\"Print This Page\"/>

<table class='box' style='background-color:#FFF'>
<tr>
<th>Question ID</th>
<th>Question</th>
<th>Answer</th>
<th>Instructor</th>
</tr>";



while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['QUESTION_ID'] . "</td>";
  echo "<td>" . $row['QUESTION_TEXT'] . "</td>";
  echo "<td>" . $row['QUESTION_ANS'] . "</td>";
  echo "<td NOWRAP>" . $row['FIRST_NAME'] . " " . $row['LAST_NAME']  . "</td>";
  echo "</tr>";
  }
echo "</table>";

?>
   
  
  </body>
</html>

<? mysql_close($conn); ?>