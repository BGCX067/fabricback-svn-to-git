<?
require_once('lib.php');

$qid = $_GET['qid'];
$tid = $_GET['tid'];
$cid = $_GET['cid'];


if (  mysql_result(mysql_query("SELECT question.QUESTION_TYPE FROM question WHERE question.QUESTION_ID='$qid'"),0,"QUESTION_TYPE") =='TF' ){
include 'edit_test_question_tf.php';
}

if (  mysql_result(mysql_query("SELECT question.QUESTION_TYPE FROM question WHERE question.QUESTION_ID='$qid'"),0,"QUESTION_TYPE") =='MCQ' ){
include 'edit_test_question_mcq.php';
}

mysql_close($conn);

?>