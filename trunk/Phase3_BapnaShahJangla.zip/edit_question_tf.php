<?php

$topic_id=$_GET['tid'];
$q_id=$_GET['qid'];

$query="SELECT * FROM question WHERE question.QUESTION_ID='$q_id'";
$result=mysql_query($query);

$TF_question=mysql_result($result,0,"QUESTION_TEXT");
$TF_points=mysql_result($result,0,"QUESTION_POINTS");
$TF_answer=mysql_result($result,0,"QUESTION_ANS");


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="topic_mgmt.php" style="color:#FFF"> Question Library Management </a> ---> <a href="view_topic.php?id=<? echo $topic_id ?> "style="color:#FFF"> View Questions in Topic </a> ---> Edit Question  </div>
  <!-- /BreadCrumbs -->

  
  
  
  <form action="view_topic.php?id=<? echo $topic_id ?>" method="POST" name="tf_form">
    <? include('error.php'); ?>
    <h1>
      Edit selected TF question
    </h1>
    <table class="box">
      <tr>
        <td>* Question</td>
        <td><input type="text" name="TF_question" value="<? echo $TF_question ?>" /></td>
      </tr>
      <tr>
        <td>* # Points</td>
        <td><input type="text" name="TF_points" value="<? echo $TF_points ?>" /></td>
      </tr>
      <tr>
        <td>* Answer</td>
        <td><select name="TF_answer"><option value="true" <? if($TF_answer=='true'){echo "selected";}?>>True</option><option value="false" <? if($TF_answer=='false'){echo "selected";}?>>False</option></select></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="topic_id" value="<? echo $topic_id ?>">
          <input type="hidden" name="question_id" value="<? echo $q_id ?>">
          <input type="hidden" name="edit_tf" value="true">          
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("tf_form");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("TF_question","req","Please enter a question");
 
 frmvalidator.addValidation("TF_points","req","Please enter number of points for this question");
 frmvalidator.addValidation("TF_points","numeric","numeric values only");
 frmvalidator.addValidation("TF_points","maxlength=2","Exceeded max number of points per question");


 
</script> 
  
  </body>
</html>

