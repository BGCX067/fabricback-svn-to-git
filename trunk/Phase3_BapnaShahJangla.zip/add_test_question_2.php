<?php
require_once('lib.php');

if($_GET['tid']!=''){
$topic_id=$_GET['tid'];
} else {
	$topic_id=$_POST['topic_id_var'];
}

$topic_name=mysql_result(mysql_query("SELECT topic.NAME FROM topic WHERE topic.TOPIC_ID='$topic_id'"),0,"NAME");

$cid=$_GET['cid'];
$tid=$_GET['tid'];
$test_id=$_GET['testid'];

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> <a href="course_exams.php?cid=<? echo $cid ?>" style="color:#FFF">Exam Management </a> ---> <a href="edit_test.php?cid=<? echo $cid ?>&tid=<? echo $test_id ?>" style="color:#FFF">View/Edit Test </a> ---> Add a Question to this Test (step 2 of 2) 
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM topic NATURAL JOIN question NATURAL JOIN instr_user WHERE TOPIC_ID=$topic_id ");

echo "
    <h1>
    Step 2: Add a question from topic \"$topic_name\"
    </h1>

<table class='box'>
<tr>
<th>Question ID</th>
<th>Question</th>
<th>Instructor</th>
</tr>";



while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['QUESTION_ID'] . "</td>";
  echo "<td>" . $row['QUESTION_TEXT'] . "</td>";
  echo "<td NOWRAP>" . $row['FIRST_NAME'] . " " . $row['LAST_NAME'] . "</td>";
  echo "<td NOWRAP><a href=\"edit_test.php?qid=" . $row['QUESTION_ID'] . "&tid=" . $test_id . "&cid=" . $cid . "&addq=true\">Add this question</a></td>";
  echo "</tr>";
  }
echo "</table>";

?>
  
  

  
  
  </body>
</html>

<? mysql_close($conn); ?>