<?php
require_once('lib.php');


$id=$_GET['id'];
$query=" SELECT * FROM topic WHERE TOPIC_ID='$id' ";
$result=mysql_query($query);

$name=mysql_result($result,0,"NAME");
?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body> 
  
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="topic_mgmt.php" style="color:#FFF">Question Library Management </a> ---> Edit Topic Name
  </div>
  <!-- /BreadCrumbs -->
  
  
  <form action="topic_mgmt.php" method="POST" name="edit_topic">
    <? include('error.php'); ?>
    <h1>
      Edit Topic Name
    </h1>
    <table class="box">
      <tr>
        <td>
          * Topic Name
        </td>
        <td>
          <input type="text" name="topicname" value="<? echo $name ?>" />
        </td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="updateBool" value="true" />
          <input type="hidden" name="id" value="<? echo $id ?>" />
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("edit_topic");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("topicname","req","Please enter a topic name");
 
</script>    
  
  </body>
</html>

<? mysql_close($conn); ?>