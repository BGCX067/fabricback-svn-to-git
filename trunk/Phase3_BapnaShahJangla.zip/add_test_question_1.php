<?php
require_once('lib.php');

$id=$_POST['id'];
$updateBool=$_POST['updateBool'];
if($updateBool){
	$query = "   UPDATE	topic SET	topic.NAME='$_POST[topicname]' WHERE	topic.TOPIC_ID='$_POST[id]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}

$addBool=$_POST['addBool'];
if($addBool){
	
	$topicname=$_POST['topicname'];
	if($topicname!=""){
	$query = "    INSERT INTO  	topic VALUES ('','$topicname')";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record added";
	}
	
	}
}


$cid=$_GET['cid'];
$tid=$_GET['tid'];


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> <a href="course_exams.php?cid=<? echo $cid ?>" style="color:#FFF">Exam Management </a> ---> <a href="edit_test.php?cid=<? echo $cid ?>&tid=<? echo $tid ?>" style="color:#FFF">View/Edit Test </a> ---> Add a Question to this Test (step 1 of 2) 
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM topic");

echo "
    <h1>
      Step 1: Select a Topic
    </h1>

<table class='box'>
<tr>
<th>Topic ID</th>
<th>Name</th>
<th>Questions</th>
</tr>";


while($row = mysql_fetch_array($result))
  {
	  if(mysql_num_rows(mysql_query("SELECT * FROM topic NATURAL JOIN question WHERE topic.TOPIC_ID='$row[TOPIC_ID]'"))!=0){
  echo "<tr>";
  echo "<td>" . $row['TOPIC_ID'] . "</td>";
  echo "<td>" . $row['NAME'] . "</td>";
  echo "<td>" . 
	mysql_num_rows(mysql_query("SELECT * FROM topic NATURAL JOIN question WHERE topic.TOPIC_ID='$row[TOPIC_ID]'"))
  
  . "</td>";
  echo "<td><a href=\"add_test_question_2.php?cid=" . $cid . "&tid=" . $row['TOPIC_ID'] . "&testid=" . $tid ."\">Choose this topic</a></td>";
  echo "</tr>";
  }
  }
echo "</table>";

?>
  
  
</body>
</html>

<? mysql_close($conn); ?>