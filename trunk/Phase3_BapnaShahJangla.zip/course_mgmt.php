<?php
require_once('lib.php');


$deleteBool=$_GET['delete'];
if($deleteBool){
	$query = "  DELETE FROM course  WHERE course.UNIQUE_COURSE_ID='$_GET[cid]'  ";

	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record deleted";
	}

}


$updateBool=$_POST['updateBool'];
if($updateBool){
	$query = "   UPDATE	course SET	course.SECTION='$_POST[section]',course.COURSENUM='$_POST[coursenum]',course.SEMESTER='$_POST[semester]',course.YEAR='$_POST[year]',course.TITLE='$_POST[title]' WHERE	course.UNIQUE_COURSE_ID='$_POST[cid]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}

$addBool=$_POST['addBool'];
if($addBool){
	if($_POST['courseNumber']!="" && $_POST['courseTitle']!="" && $_POST['courseSemester']!="" && $_POST['courseYear']!="" && $_POST['courseSection']!=""){
	$query = "    INSERT INTO course VALUES ('','$_POST[courseSection]','$_POST[courseNumber]','$_POST[courseSemester]','$_POST[courseYear]','$_POST[courseTitle]','$curr_user_id')    ";
	if(!mysql_query($query)) { echo "failed"; } else { echo "1 record added"; } ;
	}
}

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> Course Management
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM course WHERE course.INSTR_ID = '$curr_user_id'");

echo "
    <h1>
      Your Courses
    </h1>

<table class='box'>
<tr>
<th>Course No.</th>
<th>Course Title</th>
<th>Semester</th>
<th>Year</th>
<th>Section</th>
</tr>";


while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['COURSENUM'] . "</td>";
  echo "<td>" . $row['TITLE'] . "</td>";
  echo "<td>" . $row['SEMESTER'] . "</td>";
  echo "<td>" . $row['YEAR'] . "</td>";
  echo "<td>" . $row['SECTION'] . "</td>";
  echo "<td><a href=\"edit_course.php?cid=" . $row['UNIQUE_COURSE_ID'] . "\">Edit Course</a></td>";
  echo "<td><a href=\"course_mgmt.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&delete=true \">Delete Course</a></td>";
  echo "<td><a href=\"course_exams.php?cid=" . $row['UNIQUE_COURSE_ID'] . "\">Exam Management</a></td>";


  echo "</tr>";
  }
echo "</table>";

?>
  
  
  <form action="course_mgmt.php" method="POST" name="course_mgmt">
    <? include('error.php'); ?>
    <h1>
      Create a new course
    </h1>
    <table class="box">
      <tr>
        <td>* Course Number</td>
        <td><input type="text" name="courseNumber" /></td>
      </tr>
      <tr>
        <td>* Course Title</td>
        <td><input type="text" name="courseTitle" /></td>
      </tr>
      <tr>
        <td>* Course Semester</td>
        <td>
        <select name="courseSemester">
        <option value="Fall">Fall</option>
        <option value="Spring">Spring</option>
        <option value="Summer">Summer</option>        
        </select>
        </td>
      </tr>
      <tr>
        <td>* Course Year</td>
        <td><input type="text" name="courseYear" /></td>
      </tr>
      <tr>
        <td>* Course Section</td>
        <td><input type="text" name="courseSection" /></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="addBool" value="true">
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("course_mgmt");
 frmvalidator.EnableMsgsTogether();
 frmvalidator.addValidation("courseNumber","req","Please enter a course number");
 frmvalidator.addValidation("courseNumber","numeric");
 
 frmvalidator.addValidation("courseTitle","req","Please enter a course title");
 
 frmvalidator.addValidation("courseSemester","req","Please enter the course semester");

 frmvalidator.addValidation("courseYear","req","Please enter the course year (for example, 2008)");
 frmvalidator.addValidation("courseYear","numeric");
 frmvalidator.addValidation("courseYear","maxlength=4");
 frmvalidator.addValidation("courseYear","minlength=4");

 frmvalidator.addValidation("courseSection","req","Please enter the course section");
 frmvalidator.addValidation("courseSection","maxlength=2");

</script>

  </body>
</html>

<? mysql_close($conn); ?>