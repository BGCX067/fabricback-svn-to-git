<?php
require_once('lib.php');


$cid=$_GET['cid'];
$query=" SELECT * FROM course WHERE UNIQUE_COURSE_ID='$cid' ";
$result=mysql_query($query);

$section=mysql_result($result,0,"SECTION");
$coursenum=mysql_result($result,0,"COURSENUM");
$semester=mysql_result($result,0,"SEMESTER");
$year=mysql_result($result,0,"YEAR");
$title=mysql_result($result,0,"TITLE");

echo "<script language=\"JavaScript\" src=\"gen_validatorv31.js\" type=\"text/javascript\"></script>";

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body> 
  
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> Edit Course
  </div>
  <!-- /BreadCrumbs -->
  
  
  <form action="course_mgmt.php" method="POST" name="edit_course">
    <? include('error.php'); ?>
    <h1>
      Edit Course
    </h1>
    <table class="box">
      <tr>
        <td>
          * Course Number
        </td>
        <td>
          <input type="text" name="coursenum" value="<? echo $coursenum ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * Course Title
        </td>
        <td>
          <input type="text" name="title" value="<? echo $title ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * Course Section
        </td>
        <td>
          <input type="text" name="section" value="<? echo $section ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * Course Semester
        </td>
        <td>
        <select name="semester">
        <option value="Fall" <? if($semester=='Fall'){echo "selected";}?>>Fall</option>
        <option value="Spring" <? if($semester=='Spring'){echo "selected";}?>>Spring</option>
        <option value="Summer" <? if($semester=='Summer'){echo "selected";}?>>Summer</option>        
        </select>
        </td>
      </tr>
      <tr>
        <td>
          * Course Year
        </td>
        <td>
          <input type="text" name="year" value="<? echo $year ?>" />
        </td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="updateBool" value="true" />
          <input type="hidden" name="cid" value="<? echo $cid ?>" />
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
  
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("edit_course");
 frmvalidator.EnableMsgsTogether();
 frmvalidator.addValidation("coursenum","req","Please enter a course number");
 frmvalidator.addValidation("coursenum","numeric");
 
 frmvalidator.addValidation("title","req","Please enter a course title");
 
 frmvalidator.addValidation("semester","req","Please enter the course semester");

 frmvalidator.addValidation("year","req","Please enter the course year (for example, 2008)");
 frmvalidator.addValidation("year","numeric");
 frmvalidator.addValidation("year","maxlength=4");
 frmvalidator.addValidation("year","minlength=4");

 frmvalidator.addValidation("section","req","Please enter the course section");
 frmvalidator.addValidation("section","maxlength=2");

</script>
  
  
  </body>
</html>

<? mysql_close($conn); ?>