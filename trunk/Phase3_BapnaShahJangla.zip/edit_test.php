<?php
require_once('lib.php');

$addq=$_GET['addq'];
if($addq!=''){
	$query = "  INSERT INTO test_to_question VALUES ('$_GET[tid]','$_GET[qid]')  ";
	
	if(!mysql_query($query)) {
		echo "failed-- record may already exist!";
	} else {
		echo "1 record added";
	}

}



if($_POST['edit_tf']){
	
	$query = "   UPDATE	question SET question.QUESTION_TEXT='$_POST[TF_question]', question.QUESTION_POINTS='$_POST[TF_points]', question.QUESTION_ANS='$_POST[TF_answer]' WHERE	question.QUESTION_ID='$_POST[question_id]'  ";
	
	
	if(!mysql_query($query)) {
		echo "failed3";
	} else {
		echo "1 record updated";
	}
	
}





if($_POST['edit_mcq']){
	
	$query = "   UPDATE	question SET question.QUESTION_TEXT='$_POST[MCQ_question]', question.QUESTION_POINTS='$_POST[MCQ_points]', question.QUESTION_ANS='$_POST[MCQ_answer]' WHERE	question.QUESTION_ID='$_POST[question_id]'  ";
	
	
	if(!mysql_query($query)) {
		echo "failed4";
	} else {
		echo "1 record updated";
	}

mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_1_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_1_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_2_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_2_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_3_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_3_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_4_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_4_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_5_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_5_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_6_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_6_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_7_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_7_id]'    ") ;
mysql_query("    UPDATE mc_ans_wrong SET mc_ans_wrong.WRONG_ANS_TEXT='$_POST[MCQ_wrong_ans_8_text]' WHERE mc_ans_wrong.WRONG_ANS_ID='$_POST[MCQ_wrong_ans_8_id]'    ") ;	
	
}





$deleteBool=$_GET['delete'];
if($deleteBool!=''){
	$query = "  DELETE FROM test_to_question  WHERE test_to_question.QUESTION_ID='$_GET[delete]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record deleted";
	}

}



$cid=$_GET['cid'];
$tid=$_GET['tid'];
$query=" SELECT * FROM test WHERE TESTID='$tid' ";
$result=mysql_query($query);

$testTitle=mysql_result($result,0,"TEST_TITLE");


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body> 
  
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> <a href="course_exams.php?cid=<? echo $cid ?>" style="color:#FFF">Exam Management </a> ---> View/Edit Test
  </div>
  <!-- /BreadCrumbs -->
  
  
  <form action="course_exams.php?cid=<? echo $cid ?>" method="POST" name="edit_test_name">
    <? include('error.php'); ?>
    <h1>
      Edit Test "<? echo $testTitle ?>"
    </h1>
    <table class="box">
      <tr>
        <td>
          * Edit title
        </td>
        <td>
          <input type="text" name="testTitle" value="<? echo $testTitle ?>" />
        </td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="updateTitleBool" value="true" />
          <input type="hidden" name="cid" value="<? echo $cid ?>" />
          <input type="hidden" name="tid" value="<? echo $tid ?>" />
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("edit_test_name");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("testTitle","req","Please enter a name for the test before clicking submit");
 
</script>    
      
    
  <?
  $result = mysql_query("SELECT * FROM test NATURAL JOIN test_to_question NATURAL JOIN question WHERE TESTID = '$tid'");

echo "


<table class='box'>
<tr>
<th>Question ID</th>
<th>Question Title</th>
<th>Question Type</th>
<th>Question Answer</th>
<th>Question Points</th
<th NOWRAP colspan=\"2\"><a href=\"add_test_question_1.php?cid=" . $cid .  "&tid=" . $tid . "\">Add a Question to this Test</a></th>
</tr>";


while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['QUESTION_ID'] . "</td>";
  echo "<td>" . $row['QUESTION_TEXT'] . "</td>";
  echo "<td>" . $row['QUESTION_TYPE'] . "</td>";
  echo "<td>" . $row['QUESTION_ANS'] . "</td>";
  echo "<td>" . $row['QUESTION_POINTS'] . "</td>";
  echo "<td><a href=\"edit_test_question.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&tid=" . $row['TESTID'] . "&qid=" . $row['QUESTION_ID'] .  "\">Edit Question</a></td>";
  echo "<td><a href=\"edit_test.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&tid=" . $row['TESTID'] . "&delete=".  $row['QUESTION_ID'] ."\">Delete Question from Test</a></td>";

  echo "</tr>";
  }
echo "</table>";

?>



  </body>
</html>

<? mysql_close($conn); ?>