<?php
require_once('lib.php');


$id=$_GET['id'];
$query=" SELECT * FROM instr_user WHERE INSTR_ID='$id' ";
$result=mysql_query($query);

$username=mysql_result($result,$i,"USERNAME");
$firstname=mysql_result($result,$i,"FIRST_NAME");
$lastname=mysql_result($result,$i,"LAST_NAME");
$password=mysql_result($result,$i,"PASSWORD");

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="../gen_validatorv31.js" type="text/javascript"></script>    
  </head>
  <body> 
  
  
    <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="admin_home.php" style="color:#FFF">Admin Home Page </a> ---> <a href="instr_mgmt.php" style="color:#FFF">Instructor Management </a> ---> Edit Instructor Information
  </div>
  <!-- /BreadCrumbs -->
  
  
  <form action="instr_mgmt.php" method="POST" name="edit_instr">
    <? include('error.php'); ?>
    <h1>
      Update an Instructor Account
    </h1>
    <table class="box">
      <tr>
        <td>* Username</td>
        <td><input type="text" name="username" value="<? echo $username ?>"  /></td>
      </tr>
      <tr>
        <td>
          * First Name
        </td>
        <td>
          <input type="text" name="firstname" value="<? echo $firstname ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * Last Name
        </td>
        <td>
          <input type="text" name="lastname"  value="<? echo $lastname ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * New password
        </td>
        <td>
          <input type="password" name="password"  value="<? echo $password ?>" />
        </td>
      </tr>
      <tr>
        <td>
          * Re-enter new password
        </td>
        <td>
          <input type="password" name="password_retype" value="<? echo $password ?>" />
        </td>
      </tr>
      <tr>
        
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="updateBool" value="true" />
          <input type="hidden" name="id" value="<? echo $id ?>" />
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("edit_instr");
 frmvalidator.EnableMsgsTogether(); 
 
 frmvalidator.addValidation("username","req","Please enter your username");
 
 frmvalidator.addValidation("firstname","req","Please enter your first name");
 
 frmvalidator.addValidation("lastname","req","Please enter your last name");

 frmvalidator.addValidation("password","req","Please enter your password");
 frmvalidator.addValidation("password","minlength=5");

 
 frmvalidator.addValidation("password_retype","req","Please re-enter your password for verification");


</script>
  
  
  </body>
</html>

<? mysql_close($conn); ?>