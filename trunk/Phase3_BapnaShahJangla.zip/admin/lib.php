<?php


$dbhost = '192.168.1.104';
$dbuser = 'fabricba_jason';
$dbpass = 'jason4221199';

$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die                      ('Error connecting to mysql');

$dbname = 'fabricba_exammgmt';
mysql_select_db($dbname);

if(!$_COOKIE['user'] && $_SERVER['PHP_SELF']!='/admin/admin_login.php'){
	header( 'Location: admin_login.php' ) ;
}


?>