<?php
require_once('lib.php');

$id=$_POST['id'];
$updateBool=$_POST['updateBool'];
if($updateBool && $_POST['password']==$_POST['password_retype']){
	$query = "   UPDATE	instr_user SET	instr_user.USERNAME='$_POST[username]', instr_user.FIRST_NAME= '$_POST[firstname]', instr_user.LAST_NAME='$_POST[lastname]', instr_user.PASSWORD='$_POST[password]' WHERE	instr_user.INSTR_ID='$_POST[id]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}

$addBool=$_POST['addBool'];
if($addBool && $_POST['password']==$_POST['password_retype']){
	
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$username=$_POST['username'];
	$pass=$_POST['password'];
	
	if($firstname!=""){
	$query = "    INSERT INTO  	instr_user VALUES ('','$username','$password','$firstname','$lastname')";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record added";
	}
	
	}
}


$did=$_GET['did'];
if($did!=''){
	$query = "  DELETE FROM instr_user  WHERE instr_user.INSTR_ID='$did'   ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "user deleted";
	}
	

}


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="../gen_validatorv31.js" type="text/javascript"></script>    
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="admin_home.php" style="color:#FFF">Admin Home Page </a> ---> Instructor Management
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM instr_user");

echo "
    <h1>
      Instructor Account Management
    </h1>

<table class='box'>
<tr>
<th>Instructor ID</th>
<th>Username</th>
<th>Firstname</th>
<th>Lastname</th>
</tr>";



while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['INSTR_ID'] . "</td>";
  echo "<td>" . $row['USERNAME'] . "</td>";
  echo "<td>" . $row['FIRST_NAME'] . "</td>";
  echo "<td>" . $row['LAST_NAME'] . "</td>";
  echo "<td><a href=\"edit_instructor.php?id=" . $row['INSTR_ID'] . "\">Modify</a></td>";
  echo "<td><a href=\"instr_mgmt.php?did=" . $row['INSTR_ID'] . "\">Delete</a></td>";
  echo "</tr>";
  }
echo "</table>";

?>
  
  
  <form action="instr_mgmt.php" method="POST" name="create_instr">
    <? include('error.php'); ?>
    <h1>
      Create an Instructor Account
    </h1>
    <table class="box">
      <tr>
        <td>* Username</td>
        <td><input type="text" name="username" /></td>
      </tr>
      <tr>
        <td>
          * First Name
        </td>
        <td>
          <input type="text" name="firstname" />
        </td>
      </tr>
      <tr>
        <td>
          * Last Name
        </td>
        <td>
          <input type="text" name="lastname" />
        </td>
      </tr>
      <tr>
        <td>
          * Choose a password
        </td>
        <td>
          <input type="password" name="password" />
        </td>
      </tr>
      <tr>
        <td>
          * Re-enter password
        </td>
        <td>
          <input type="password" name="password_retype" />
          <input type="hidden" name="addBool" value="true">
        </td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("create_instr");
 frmvalidator.EnableMsgsTogether(); 
 
 frmvalidator.addValidation("username","req","Please enter your username");
 
 frmvalidator.addValidation("firstname","req","Please enter your first name");
 
 frmvalidator.addValidation("lastname","req","Please enter your last name");

 frmvalidator.addValidation("password","req","Please enter your password");
 frmvalidator.addValidation("password","minlength=5");

 
 frmvalidator.addValidation("password_retype","req","Please re-enter your password for verification");


</script>



  </body>
</html>

<? mysql_close($conn); ?>