<?php
require_once('lib.php');

$id=$_POST['id'];
$updateBool=$_POST['updateBool'];
if($updateBool){
	$query = "   UPDATE	topic SET	topic.NAME='$_POST[topicname]' WHERE	topic.TOPIC_ID='$_POST[id]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}




$deleteBool=$_GET['deleteBool'];
$id=$_GET['id'];
if($deleteBool){
	$query = "  DELETE FROM topic  WHERE topic.TOPIC_ID='$id'   ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "topic deleted";
	}
	
	$query2 = " DELETE FROM question WHERE question.TOPIC_ID='$id' ";
	if(!mysql_query($query2)) {
		echo "failed";
	} else {
		echo " questions in topic deleted";
	}


}


$addBool=$_POST['addBool'];
if($addBool){
	
	$topicname=$_POST['topicname'];
	if($topicname!=""){
	$query = "    INSERT INTO  	topic VALUES ('','$topicname')";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record added";
	}
	
	}
}

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> Question Library Management
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM topic ORDER BY TOPIC_ID ");

echo "
    <h1>
      Topics
    </h1>

<table class='box'>
<tr>
<th>Topic ID</th>
<th>Name</th>
<th># Questions</th>
<th colspan=\"3\"><a href=\"view_all_questions.php\">Display all questions (printable version)</a></th>
</tr>";


while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['TOPIC_ID'] . "</td>";
  echo "<td>" . $row['NAME'] . "</td>";
  echo "<td>" . 
	mysql_num_rows(mysql_query("SELECT * FROM topic NATURAL JOIN question WHERE topic.TOPIC_ID='$row[TOPIC_ID]'  "))
  
  . "</td>";
  echo "<td><a href=\"edit_topic.php?id=" . $row['TOPIC_ID'] . "\">Edit Name</a></td>";
  echo "<td><a href=\"view_topic.php?id=" . $row['TOPIC_ID'] . "\">Select Topic</a></td>";
  echo "<td><a href=\"topic_mgmt.php?id=" . $row['TOPIC_ID'] . "&deleteBool=true\">Delete Topic</a></td>";
  echo "</tr>";
  }
echo "</table>";

?>
  
  
  <form action="topic_mgmt.php" method="POST" name="topic_mgmt">
    <? include('error.php'); ?>
    <h1>
      Create a new topic
    </h1>
    <table class="box">
      <tr>
        <td>* Topic Name</td>
        <td><input type="text" name="topicname" /></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="addBool" value="true">
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("topic_mgmt");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("topicname","req","Please enter a topic name");
 
</script>  
  
  </body>
</html>

<? mysql_close($conn); ?>