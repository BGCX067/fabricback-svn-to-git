<?php
require_once('lib.php');

$tid=$_GET['tid'];
$query=" SELECT * FROM test WHERE TESTID='$tid' ";
$result=mysql_query($query);

$testTitle=mysql_result($result,0,"TEST_TITLE");


?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
  </head>
  <body> 
  
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> <a href="course_exams.php?cid=<? echo $cid ?>" style="color:#FFF">Exam Management </a> ---> Print Test
  </div>
  <!-- /BreadCrumbs -->
  
  
      <h1>
      <? echo $testTitle ?>
    </h1>

  <?
  $result = mysql_query("SELECT * FROM test NATURAL JOIN test_to_question NATURAL JOIN question WHERE TESTID = '$tid' ORDER BY RAND()");

echo "
<br>
<input type=\"button\" onClick=\"window.print()\" value=\"Print This Page\"/>

<table class='box' style='background-color:#FFF'>
<tr>
<th colspan=\"5\">Name: ______________________________</th>
</tr>
<tr>
<th colspan=\"5\">Section: ____________________________</th>
</tr>


";

$num=1;
while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td width=300><b>Question " . $num . ":</b>&nbsp;(" . $row['QUESTION_POINTS'] ." points)</td>";
  echo "<tr><td>Q: " . $row['QUESTION_TEXT'] . "</td></tr>";
    echo "<td colspan=\"2\">Ans (please select): </td>";

  if ( $row['QUESTION_TYPE']=='TF' ){
	    echo "<td colspan=\"2\">TRUE</td>";
	    echo "<td colspan=\"2\">FALSE</td>";
  } else {

  

$result2 = mysql_query("SELECT * FROM question NATURAL JOIN mc_ans_wrong WHERE QUESTION_ID = '$row[QUESTION_ID]' ORDER BY RAND() ");
$currLoc=1;
$rand=rand(1, 8);
$random=rand(1,2);

if ($random==1){
	while($row2 = mysql_fetch_array($result2)){
		if($rand==$currLoc){
			echo "<td>" . $row['QUESTION_ANS'] . "</td>";
			$currLoc=$currLoc+1;
		}
		$currLoc=$currLoc+1;
		if($row2['WRONG_ANS_TEXT']!=''){echo "<td>" . $row2['WRONG_ANS_TEXT'] . "</td>";}
	}
} else {
	while($row2 = mysql_fetch_array($result2)){
		if($row2['WRONG_ANS_TEXT']!=''){echo "<td>" . $row2['WRONG_ANS_TEXT'] . "</td>";}
		if($rand==$currLoc){
			echo "<td>" . $row['QUESTION_ANS'] . "</td>";
			$currLoc=$currLoc+1;
		}
		$currLoc=$currLoc+1;
	}
}

  }

  echo "</tr>";
  $num=$num+1;

  }
echo "</table>";
?>


  </form></body>
</html>

<? mysql_close($conn); ?>