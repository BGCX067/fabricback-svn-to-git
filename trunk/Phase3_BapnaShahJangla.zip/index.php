<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="index.css" type="text/css"/>
    <title>Georgia Tech Exam Management System</title>
  </head>
  <body>
    <h1>
      Georgia Tech Exam Management System
    </h1>
    <table>
      <tr>
        <td class="box">
          <h2><a href="admin/admin_login.php">Administrator</a></h2>
          <br />
        </td>
        <td class="middleSpace">
        </td>
        <td class="box">
          <h2><a href="instructor_login.php">Instructor</a></h2>
          <br />
        </td>
      </tr>
    </table>
  </body>
</html>

