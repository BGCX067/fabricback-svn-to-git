--
-- Database: `exam_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `USERNAME` varchar(32) NOT NULL,
  `PASSWORD` varchar(32) NOT NULL,
  `TITLE` varchar(32),
  PRIMARY KEY  (`USERNAME`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------


--
-- Table structure for table `instr_user`
--

CREATE TABLE `instr_user` (
  `INSTR_ID` int(11) NOT NULL auto_increment,
  `USERNAME` varchar(32) NOT NULL,
  `PASSWORD` varchar(32) NOT NULL,
  `FIRST_NAME` varchar(32) NOT NULL,
  `LAST_NAME` varchar(11) NOT NULL,
  PRIMARY KEY  (`INSTR_ID`),
  UNIQUE KEY `UNIQUE_INSTR` (`USERNAME`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `UNIQUE_COURSE_ID` int(11) NOT NULL auto_increment,
  `SECTION` varchar(2) NOT NULL,
  `COURSENUM` int(11) NOT NULL,
  `SEMESTER` varchar(25) NOT NULL,
  `YEAR` int(11) NOT NULL,
  `TITLE` varchar(25) NOT NULL,
  `INSTR_ID` int(11) NOT NULL,
  PRIMARY KEY  (`UNIQUE_COURSE_ID`),
  UNIQUE KEY `UNIQUE_COURSE` (`SECTION`,`COURSENUM`,`SEMESTER`,`YEAR`,`INSTR_ID`),
  CONSTRAINT FOREIGN KEY (INSTR_ID) REFERENCES instr_user(INSTR_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------


--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `TOPIC_ID` int(11) NOT NULL auto_increment,
  `NAME` varchar(32) NOT NULL,
  PRIMARY KEY  (`TOPIC_ID`),
  UNIQUE KEY `UNIQUE_TOPIC` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------


--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `QUESTION_ID` int(11) NOT NULL auto_increment,
  `QUESTION_TEXT` varchar(50) NOT NULL,
  `QUESTION_POINTS` int(11) NOT NULL,
  `QUESTION_TYPE` varchar(3) NOT NULL,
  `INSTR_ID` int(11) NOT NULL,
  `TOPIC_ID` int(11) NOT NULL,
  `QUESTION_ANS` varchar(50) NOT NULL,
  PRIMARY KEY  (`QUESTION_ID`),
  CONSTRAINT FOREIGN KEY (INSTR_ID) REFERENCES instr_user(INSTR_ID) ON DELETE CASCADE,
  CONSTRAINT FOREIGN KEY (TOPIC_ID) REFERENCES topic(TOPIC_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------


--
-- Table structure for table `mc_ans_wrong`
--

CREATE TABLE `mc_ans_wrong` (
  `QUESTION_ID` int(11) NOT NULL,
  `WRONG_ANS_ID` int(11) NOT NULL auto_increment,
  `WRONG_ANS_TEXT` varchar(50),
  PRIMARY KEY  (`WRONG_ANS_ID`),
  CONSTRAINT FOREIGN KEY (QUESTION_ID) REFERENCES question(QUESTION_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------



--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `TESTID` int(11) NOT NULL auto_increment,
  `UNIQUE_COURSE_ID` int(11) NOT NULL,
  `TEST_TITLE` varchar(32) NOT NULL,
  PRIMARY KEY  (`TESTID`),
  CONSTRAINT FOREIGN KEY (UNIQUE_COURSE_ID) REFERENCES course(UNIQUE_COURSE_ID) ON DELETE CASCADE,
  UNIQUE KEY `UNIQUE_TEST` (`UNIQUE_COURSE_ID`,`TEST_TITLE`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test_to_question`
--

CREATE TABLE `test_to_question` (
  `TESTID` int(11) NOT NULL,
  `QUESTION_ID` int(11) NOT NULL,
  PRIMARY KEY  (`TESTID`,`QUESTION_ID`),
  CONSTRAINT FOREIGN KEY (TESTID) REFERENCES test(TESTID) ON DELETE CASCADE,
  CONSTRAINT FOREIGN KEY (QUESTION_ID) REFERENCES question(QUESTION_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------


