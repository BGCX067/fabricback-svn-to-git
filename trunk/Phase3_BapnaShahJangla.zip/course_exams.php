<?php
require_once('lib.php');


$updateTitleBool=$_POST['updateTitleBool'];
if($updateTitleBool){
	$query = "  UPDATE test  SET test.TEST_TITLE='$_POST[testTitle]' WHERE test.TESTID='$_POST[tid]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}


$deleteBool=$_GET['delete'];
if($deleteBool!=''){
	$query = "  DELETE FROM test  WHERE test.TESTID='$_GET[delete]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record deleted";
	}

}
	

$updateBool=$_POST['updateBool'];
if($updateBool){
	$query = "   UPDATE	course SET	course.SECTION='$_POST[section]',course.COURSENUM='$_POST[coursenum]',course.SEMESTER='$_POST[semester]',course.YEAR='$_POST[year]',course.TITLE='$_POST[title]' WHERE	course.UNIQUE_COURSE_ID='$_POST[cid]'  ";
	
	if(!mysql_query($query)) {
		echo "failed";
	} else {
		echo "1 record updated";
	}

}

$addBool=$_POST['addBool'];
if($addBool){
	if($_POST['testTitle']!="" && $_POST['cid']!=""){
	$query = "    INSERT INTO test VALUES ('','$_POST[cid]','$_POST[testTitle]')    ";
	if(!mysql_query($query)) { echo "failed"; } else { echo "1 record added"; } ;
	}
}

?>





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="signup.css" type="text/css"/>
    <script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
  </head>
  <body>
  
  <!-- BreadCrumbs -->
  <div style="font-size:12px; color:#FFF">
  Your Location:
  <a href="instructor_home.php" style="color:#FFF">Instructor Home Page </a> ---> <a href="course_mgmt.php" style="color:#FFF">Course Management </a> ---> Exam Management
  </div>
  <!-- /BreadCrumbs -->

  
  <?
  $result = mysql_query("SELECT * FROM course WHERE UNIQUE_COURSE_ID = '$_GET[cid]'");
	$coursename=mysql_result($result,0,"TITLE");
  $result2 = mysql_query("SELECT * FROM course NATURAL JOIN test WHERE UNIQUE_COURSE_ID = '$_GET[cid]'");

echo "
    <h1>
      Tests in course \"" . $coursename . "\"
    </h1>

<table class='box'>
<tr>
<th>Test ID</th>
<th>Test Title</th>

</tr>";


while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo "<td>" . $row['TESTID'] . "</td>";
  echo "<td>" . $row['TEST_TITLE'] . "</td>";
  echo "<td><a href=\"edit_test.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&tid=" . $row['TESTID'] . "\">View/Edit Test</a></td>";
  echo "<td><a href=\"view_test.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&tid=".  $row['TESTID'] . "\">Print Test</a></td>";  
  echo "<td><a href=\"course_exams.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&delete=".  $row['TESTID'] ."\">Delete Test</a></td>";
  echo "<td><a href=\"test_report.php?cid=" . $row['UNIQUE_COURSE_ID'] . "&tid=" . $row['TESTID'] . "\">Report</a></td>";


  echo "</tr>";
  }
echo "</table>";

?>
  
  
  <form action="course_exams.php?cid=<? echo $_GET[cid] ?>" method="POST" name="exam_mgmt">
    <? include('error.php'); ?>
    <h1>
      Create a new test in this course
    </h1>
    <table class="box">
      <tr>
        <td>* Test Title</td>
        <td><input type="text" name="testTitle" /></td>
      </tr>
      <tr>
        <td colspan="2" class="submitCell">
          <input type="hidden" name="cid" value="<? echo $_GET[cid]; ?>">
          <input type="hidden" name="addBool" value="true">
          <input type="Submit" value="Submit" class="btn" />
        </td>
      </tr>
    </table>
  </form>
<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("exam_mgmt");
 frmvalidator.EnableMsgsTogether();  
 frmvalidator.addValidation("testTitle","req","Please enter a name for the test");
 
</script>  
    
  
  </body>
</html>

<? mysql_close($conn); ?>